import logging, json, importio, latch
import pymongo
from pymongo import MongoClient
import time, datetime
import xml.dom.minidom
import urllib2




class newsTracker():
# To use an API key for authentication, use the following code:
    def __init__(self):
        self.collection = ""
        #client = MongoClient('localhost', 27017)
        #db = client['newsTrackerDB']
        #self.collection = db['newsCollection']

        self.channels = ["TNews","V6NewsTelugu","ntvteluguhd", "abntelugutv", "tv9telugulive", "TV5newschannel", "CVRNewsOfficial", "6tv", "6tvtelangana", "inews", "sakshinews"]
        #self.channels = ["TNews"]
        # Because import.io queries are asynchronous, for this simple script we will use a "latch"
        # to stop the script from exiting before all of our queries are returned
        # For more information on the latch class, see the latch.py file included in this client library
        

        # Define here a global variable that we can put all our results in to when they come back from
        # the server, so we can use the data later on in the script
        self.dataRows = []

  # In order to receive the data from the queries we issue, we need to define a callback method
  # This method will receive each message that comes back from the queries, and we can take that
  # data and store it for use in our app
    def callback(self,query, message):
        #global dataRows
        # Disconnect messages happen if we disconnect the client library while a query is in progress
        if message["type"] == "DISCONNECT":
          print "Query in progress when library disconnected"
          print json.dumps(message["data"], indent = 4)

        # Check the message we receive actually has some data in it
        if message["type"] == "MESSAGE":
          if "errorType" in message["data"]:
            # In this case, we received a message, but it was an error from the external service
            print "Got an error!" 
            print json.dumps(message["data"], indent = 4)
          else:
            # We got a message and it was not an error, so we can process the data
            print "Got data!"
            #print json.dumps(message["data"], indent = 4)
            # Save the data we got in our dataRows variable for later
            self.dataRows.extend(message["data"]["results"])

        # When the query is finished, countdown the latch so the program can continue when everything is done
        if query.finished(): self.queryLatch.countdown()


    def continuousTracker(self):
        while True:
            try:
                self.queryLatch = latch.latch(11)
                self.dataRows = []
                self.client = importio.importio(user_id="a8d62747-88de-469a-8677-4169bf4d61fc", api_key="huj9kbIe0iL7VnQUrQspa9nqnr8NCrITL/37MW2ZzWG9ex0tn1NaYHdobhM2PC3uwj89S6XfDs1iPW5MGjL6dg==", host="https://query.import.io")

                # Once we have started the client and authenticated, we need to connect it to the server:
                self.client.connect()
                # Issue queries to your data sources and with your inputs
                # You can modify the inputs and connectorGuids so as to query your own sources
                # Query for tile TNews

                for channel in self.channels:
                    print "Querying for %s channel"%channel
                    self.client.query({
                    "connectorGuids": [
                    "5b848e5d-b1d1-40a4-afad-95be3428a641"
                    ],
                    "input": {
                    "webpage/url": "https://www.youtube.com/user/%s/videos?flow=list&view=0&sort=dd&live_view=500"%channel
                    }
                    }, self.callback)
                
                print "Queries dispatched, now waiting for results"

                # Now we have issued all of the queries, we can "await" on the latch so that we know when it is all done
                self.queryLatch.await()

                print "Latch has completed, all results returned"

                # It is best practice to disconnect when you are finished sending queries and getting data - it allows us to
                # clean up resources on the client and the server
                self.client.disconnect()

                # Now we can print out the data we got
                print "All data received:"
                output = json.dumps(self.dataRows, indent = 4)
                print len(json.loads(output))
                print output
                
                print "inserting into DB"
                
                for l in self.dataRows:
                    #print l['description']
                    print l.keys()
                    if "video_description" in l.keys():
                        
                        #print l
                        #l[u"timeStamp"] = unicode(str(datetime.datetime.now()).split('.')[0])
                        # Getting video id 
                        video_id = l['video_link']
                        print video_id
                        video_id = video_id.split('v=')[1].strip()
                        print video_id
                        l[u'video_id'] = video_id
                        # Getting video posted date and time
                        req = urllib2.Request("https://www.googleapis.com/youtube/v3/videos?id=%s&part=snippet,statistics,recordingDetails&key=AIzaSyA_ltEFFYL4E_rOBYkQtA8aKHnL5QR_uMA"%video_id)
                        #req = urllib2.Request("http://gdata.youtube.com/feeds/api/videos/%s?v=2"%video_id)
                        response = urllib2.urlopen(req)
                        page = response.read()

                        res = json.loads(page)
                        #print res["localized"]
                        date = res["items"][0]["snippet"]["publishedAt"]
                        #print res["items"][0]["publishedAt"]
                        '''
                        

                        
                        dom = xml.dom.minidom.parseString(page)
                        c = dom.getElementsByTagName('items')[0]
                        print c
                        d = dom.getElementsByTagName('publishedAt')
                        print d
                        date = d.firstChild.data
                        '''
                        date = date.replace("T"," ")
                        print date
                        time.sleep(1)
                        '''
                        try:
                            self.collection.insert(l,continue_on_error=True)
                            
                        except pymongo.errors.DuplicateKeyError:
                            pass
                        '''
                    else:
                        print "empty dict so skipping"

                
                
                #self.client.disconnect()
                #print self.dataRows
                print "Sleeping for next 60 mins"
                time.sleep(3600)
            except KeyboardInterrupt:
                self.client.disconnect()

if __name__ == "__main__":
    c = newsTracker()
    c.continuousTracker()



