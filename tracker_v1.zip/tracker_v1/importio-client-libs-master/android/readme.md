## Android

For the Android platform, please see the "java" directory, which contains a lightweight client.

Note that this version requires Android API Level 9 (Gingerbread).