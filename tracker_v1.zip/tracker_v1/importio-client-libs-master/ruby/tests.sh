#!/bin/bash
# Arguments: host, username, password, user GUID, API key
ruby1.9.1 test/test_importio.rb $1 $2 $3 $4 $5