#!/bin/bash
# Arguments: host, username, password, user GUID, API key
python importio/test/test_importio.py $1 $2 $3 $4 $5